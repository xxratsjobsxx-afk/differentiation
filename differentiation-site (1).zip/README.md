# Differentiation · animated

A single, self-contained HTML page: a six-level animated lesson on differentiation,
plus a separate quiz page with 531 questions, five genres, adjustable length, a
clock, a "can you go back" setting, grading and a marking sheet with pictures.

Everything is in **index.html**. No fonts, scripts, images or CDNs are loaded —
it works offline, and on an iPhone in Safari.

## Publish it in two minutes (GitHub Pages)

1. Go to github.com → **New repository**. Name it something like `differentiation`,
   choose **Public**, click **Create repository**.
2. On the empty repo page click **uploading an existing file** and drag in
   **index.html** (that one file is the whole site). Click **Commit changes**.
3. In the repo: **Settings → Pages**. Under *Build and deployment* set
   **Source: Deploy from a branch**, **Branch: main**, **Folder: / (root)** → **Save**.
4. Wait 1–2 minutes, refresh the Pages settings screen; the URL appears:
   `https://YOUR-USERNAME.github.io/differentiation/`

Open that on the phone and add it to the home screen. The URL never changes.

To update later: replace index.html in the repo (same upload button) and wait a minute.
